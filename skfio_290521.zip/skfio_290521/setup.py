import setuptools

setuptools.setup()

