# skf-IO
Convert Slater-Koster files, DFTB+ &lt;=> analytical representation, for use in parameterization workflows. 
